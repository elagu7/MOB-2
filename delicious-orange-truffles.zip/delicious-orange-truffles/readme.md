Codigo base para la experiencia `MOB-2`

No tienen que cambiar nada en el archivo `HabitCard.js`

Ahí se definió el componente que usarán para cada tarjeta del habito. Este tiene un botón para eliminarlo, el nombre del habito y el contador actualizable con botones.